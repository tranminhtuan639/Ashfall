  // The browser host simulates the Raptor wave. The HTTP process only relays packets.
  function setupArenaLan(game) {
    const { player, input, weapon, hud, level, defense } = game;
    const raptors = defense.raptors.slice(0, 3);
    const origin = new W(), shotDirection = new W(), endpoint = new W();
    const remote = {
      pos: new W(), eye: new W(), yaw: 0, pitch: 0, alive: false, health: 100, hurtAt: -Infinity,
      damage(amount) {
        if (!this.alive) return;
        this.health = Math.max(0, this.health - amount);
        this.alive = this.health > 0;
        this.hurtAt = performance.now();
      },
    };
    const avatar = new lt.Group(), indicator = new lt.Group();
    const suit = new lt.MeshStandardMaterial({ color: 0x42d0ff, emissive: 0x164562, roughness: .65 });
    const capsule = new lt.Mesh(new lt.CapsuleGeometry(.34, .94, 5, 10), suit);
    capsule.position.y = .81;
    capsule.castShadow = true;
    const aimMarker = new lt.Mesh(new lt.ConeGeometry(.12, .58, 8), suit);
    aimMarker.rotation.x = -Math.PI / 2;
    aimMarker.position.z = -.75;
    indicator.position.y = 1.45;
    indicator.rotation.order = "YXZ";
    indicator.add(aimMarker);
    avatar.visible = false;
    avatar.add(capsule, indicator);
    game.scene.add(avatar);

    const session = { state: "title", update, start() {} };
    let role, credentials, generation = 0, outbound = [], connected = false;
    let synced = false, remaining = 3, phase = "waiting", countdown = 0, nextSend = 0, nextGuestShot = 0;

    const ui = document.createElement("section");
    ui.className = "arena-lan";
    ui.innerHTML = `
      <style>
        .arena-lan{position:absolute;inset:0;z-index:15;font:15px/1.45 system-ui,sans-serif;color:#f4e8dc;pointer-events:none}
        .arena-lan [hidden]{display:none!important}
        .arena-lan-panel{position:absolute;left:clamp(14px,7vw,110px);top:50%;transform:translateY(-50%);width:min(430px,calc(100% - 28px));background:#1e1512ef;border:1px solid #b5916d;padding:24px;pointer-events:auto}
        .arena-lan h1{margin:0 0 12px;font-size:clamp(23px,6vw,38px)}
        .arena-lan button,.arena-lan input{background:#352923;color:#fff4df;border:1px solid #a6845f;padding:8px 12px;font:inherit;border-radius:3px}
        .arena-lan button{cursor:pointer;margin:0 6px 0 0}.arena-lan button:disabled{opacity:.55}
        .arena-lan button:focus-visible,.arena-lan input:focus-visible{outline:2px solid #ffbc64}
        .arena-lan input{width:96px}.arena-lan label{display:block;margin-bottom:4px}
        .arena-lan p{margin:10px 0}.arena-lan-status{color:#ffd19c;min-height:1.5em}
        .arena-lan-match{position:absolute;right:16px;top:90px;background:#1b1411d9;padding:9px 11px;max-width:44vw;pointer-events:auto}
        .arena-lan-match button{margin-top:6px}.arena-lan-match p{margin:0}
      </style>
      <div class="arena-lan-panel">
        <h1>Ashfall · LAN Co-op</h1>
        <p>Phòng 2 người · Một đợt Raptor</p>
        <p>Vào sân, bấm chuột để khóa góc nhìn. WASD di chuyển, chuột trái bắn.</p>
        <button data-host>Host</button><button data-join>Join</button>
        <div data-entry hidden><label for="arena-lan-code">Mã phòng</label>
          <input id="arena-lan-code" inputmode="numeric" maxlength="6" autocomplete="off">
          <button data-enter>Vào phòng</button></div>
        <p class="arena-lan-status" data-status role="status"></p>
        <button data-cancel hidden>Quay lại</button>
      </div>
      <div class="arena-lan-match" hidden><p data-match></p><button data-leave>Rời phòng</button></div>`;
    document.getElementById("app").append(ui);
    const node = selector => ui.querySelector(selector);
    const panel = node(".arena-lan-panel"), match = node(".arena-lan-match"), entry = node("[data-entry]");
    const codeInput = node("input"), status = node("[data-status]"), matchText = node("[data-match]");
    const hostButton = node("[data-host]"), joinButton = node("[data-join]"), enter = node("[data-enter]");
    const cancel = node("[data-cancel]");
    game.lan = { players: () => remote.alive ? [player, remote] : [player] };
    player.reset({ pos: new W(-4, 0, level.arena.B - 8), yaw: 0 });
    player.enabled = false;
    weapon.setVisible?.(false);

    const api = async (route, data, keepalive = false) => {
      const response = await fetch("/lan/" + route, {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data), signal: AbortSignal.timeout(4500), keepalive,
      });
      let result;
      try { result = await response.json(); }
      catch { throw new Error("Hãy mở game qua ashfall_coop_server.py."); }
      if (!response.ok) throw new Error(result.error || "Máy Host không phản hồi.");
      return result;
    };
    function send(packet) {
      if (connected && outbound.length < 64) outbound.push(JSON.stringify(packet));
    }
    function leave(message = "") {
      generation++;
      if (credentials) api("leave", credentials, true).catch(() => {});
      credentials = null;
      connected = synced = remote.alive = avatar.visible = false;
      outbound = [];
      session.state = "title";
      player.enabled = false;
      input.setGameplay?.(false);
      input.exitLock?.();
      weapon.setVisible?.(false);
      hud.show(false);
      for (const unit of raptors) unit.reset();
      level.resetArenaEntry?.();
      panel.hidden = false;
      match.hidden = entry.hidden = cancel.hidden = true;
      hostButton.disabled = joinButton.disabled = enter.disabled = false;
      status.textContent = message;
    }
    const pose = () => ({
      position: player.pos.toArray(), eye: player.eye.toArray(), yaw: player.yaw, pitch: player.pitch,
    });
    function startWave() {
      phase = "countdown";
      countdown = 4;
      remaining = raptors.length;
      nextSend = nextGuestShot = 0;
      synced = role === "host";
      const z = level.arena.B - 8, hostX = -4, guestX = 4;
      remote.pos.set(role === "host" ? guestX : hostX, 0, z);
      remote.eye.copy(remote.pos).add(new W(0, 1.6, 0));
      remote.yaw = remote.pitch = 0;
      remote.alive = true;
      remote.health = 100;
      remote.hurtAt = -Infinity;
      avatar.position.copy(remote.pos);
      avatar.visible = true;
      suit.color.setHex(role === "host" ? 0xffb94d : 0x42d0ff);
      suit.emissive.setHex(role === "host" ? 0x5d3012 : 0x164562);
      player.reset({ pos: new W(role === "host" ? hostX : guestX, 0, z), yaw: 0 });
      weapon.reset?.();
      weapon.setVisible?.(true);
      player.enabled = true;
      input.setGameplay?.(true);
      game.audio?.resume?.();
      hud.show(true);
      session.state = "playing";
      panel.hidden = true;
      match.hidden = false;
      document.activeElement?.blur();
    }
    function viewPacket(data) {
      if (!data || !Array.isArray(data.position) || !Array.isArray(data.eye) ||
          data.position.length !== 3 || data.eye.length !== 3 ||
          ![...data.position, ...data.eye, data.yaw, data.pitch].every(Number.isFinite)) return false;
      if (Math.abs(data.position[0]) > level.arena.A + 4 || Math.abs(data.position[2]) > level.arena.B + 1 ||
          data.position[1] < -1 || data.position[1] > 4) return false;
      remote.pos.fromArray(data.position);
      remote.eye.fromArray(data.eye);
      if (remote.eye.distanceToSquared(remote.pos) > 9) remote.eye.copy(remote.pos).add(new W(0, 1.6, 0));
      remote.yaw = data.yaw;
      remote.pitch = data.pitch;
      return true;
    }
    const localShot = game.combat.playerShot.bind(game.combat);
    function takeShot(index, from, direction, options) {
      const impact = localShot(from, direction, options);
      endpoint.copy(impact?.point || origin.copy(from).addScaledVector(direction, 65));
      if (index === 1) game.fx?.tracer?.(from, endpoint);
      send({ type: "trace", index, from: from.toArray(), to: endpoint.toArray() });
      return impact;
    }
    game.combat.playerShot = (from, direction, options) => {
      if (phase !== "active") {
        return { point: endpoint.copy(from).addScaledVector(direction, 65) };
      }
      if (role === "host") return takeShot(0, from, direction, options);
      send({ type: "shot", pose: pose(), direction: direction.toArray() });
      return { point: endpoint.copy(from).addScaledVector(direction, 65) };
    };

    function receive(raw) {
      let packet;
      try { packet = JSON.parse(raw); } catch { return; }
      if (!packet || typeof packet !== "object") return;
      if (role === "host") {
        if (packet.type === "pose") viewPacket(packet.pose);
        if (packet.type !== "shot" || phase !== "active" || !remote.alive || !viewPacket(packet.pose) ||
            !Array.isArray(packet.direction) || packet.direction.length !== 3 ||
            !packet.direction.every(Number.isFinite)) return;
        const now = performance.now();
        if (now < nextGuestShot) return;
        shotDirection.fromArray(packet.direction);
        if (shotDirection.lengthSq() < .81 || shotDirection.lengthSq() > 1.21) return;
        nextGuestShot = now + 1000 * 60 / O_ * .90;
        takeShot(1, remote.eye, shotDirection.normalize(), { damage: H_, range: V_ });
        return;
      }
      if (packet.type === "trace" && packet.index === 0 && Array.isArray(packet.from) && Array.isArray(packet.to)) {
        game.fx?.tracer?.(origin.fromArray(packet.from), endpoint.fromArray(packet.to));
        return;
      }
      if (packet.type !== "world" || !viewPacket(packet.hostPose)) return;
      synced = true;
      phase = packet.phase;
      countdown = packet.countdown;
      remaining = packet.remaining;
      remote.alive = packet.hostAlive;
      if (Number.isFinite(packet.guestHealth)) {
        if (packet.guestHealth < player.health) player.damage(player.health - packet.guestHealth, remote.pos);
        if (player.alive) player.health = packet.guestHealth;
      }
      if (Array.isArray(packet.raptors)) packet.raptors.forEach((snapshot, index) => {
        if (snapshot && snapshot.phase !== "ready") raptors[index]?.lanApply(snapshot);
      });
    }

    async function poll(epoch) {
      if (epoch !== generation || !credentials) return;
      try {
        const data = await api("poll", { ...credentials, packets: outbound.splice(0, 32) });
        if (epoch !== generation) return;
        if (data.connected && !connected) {
          connected = true;
          startWave();
        }
        for (const packet of data.packets) receive(packet);
        setTimeout(() => poll(epoch), connected ? 30 : 230);
      } catch (error) {
        if (epoch === generation) leave(error.message || "Mất kết nối tới máy Host.");
      }
    }
    async function joinRoom(mode) {
      const code = codeInput.value.trim();
      if (mode === "join" && !/^\d{6}$/.test(code)) {
        status.textContent = "Nhập mã phòng gồm 6 số.";
        return;
      }
      if (raptors.length < 3) {
        status.textContent = "Bản build này thiếu ba slot Raptor.";
        return;
      }
      game.audio?.resume?.();
      const epoch = ++generation;
      hostButton.disabled = joinButton.disabled = enter.disabled = true;
      cancel.hidden = false;
      status.textContent = mode === "host" ? "Đang tạo phòng…" : "Đang vào phòng…";
      try {
        const result = await api(mode, mode === "join" ? { code } : {});
        if (epoch !== generation) { api("leave", result).catch(() => {}); return; }
        role = mode;
        credentials = result;
        status.textContent = mode === "host" ? `Mã phòng: ${result.code} · Đang chờ người Join` : "Đang kết nối…";
        poll(epoch);
      } catch (error) {
        if (epoch === generation) leave(error.message);
      }
    }
    hostButton.onclick = () => joinRoom("host");
    joinButton.onclick = () => {
      entry.hidden = cancel.hidden = false;
      hostButton.disabled = joinButton.disabled = true;
      codeInput.focus();
    };
    enter.onclick = () => joinRoom("join");
    cancel.onclick = node("[data-leave]").onclick = () => leave();
    window.addEventListener("pagehide", () => { if (credentials) leave(); });

    function simulate(dt, now) {
      if (phase === "countdown" && (countdown -= dt) <= 0) {
        const z = -level.arena.B + 7;
        [-5, 0, 5].forEach((x, index) => raptors[index].start(new W(x, 0, z), { targetPlayer: true }));
        phase = "active";
      }
      if (phase === "active") {
        for (const unit of raptors) unit.update(dt);
        remaining = raptors.filter(unit => unit.alive).length;
        if (raptors.every(unit => unit.done)) phase = "victory";
        else if (!player.alive && !remote.alive) phase = "defeat";
        if (remote.alive && now - remote.hurtAt >= 4000) remote.health = Math.min(100, remote.health + 12 * dt);
      }
    }
    function update(dt) {
      if (!connected) return false;
      const now = performance.now();
      if (role === "host") simulate(dt, now);
      else for (const unit of raptors) unit.lanAnimate(dt);
      if (now >= nextSend) {
        nextSend = now + 48;
        send(role === "host" ? { type: "world", hostPose: pose(), hostAlive: player.alive,
          guestHealth: remote.health, phase, countdown, remaining, raptors: raptors.map(unit => unit.lanSnapshot()) }
          : { type: "pose", pose: pose() });
      }
      avatar.visible = remote.alive;
      avatar.position.lerp(remote.pos, Math.min(1, dt * 19));
      indicator.rotation.set(remote.pitch, remote.yaw, 0, "YXZ");
      const label = !synced ? "Đang đồng bộ…" : phase === "countdown" ? `Đợt 1 bắt đầu sau ${Math.max(0, Math.ceil(countdown))} giây`
        : phase === "victory" ? "Đợt 1 hoàn tất" : phase === "defeat" ? "Cả đội đã bị hạ" : `Đợt 1 · Còn ${remaining} Raptor`;
      const text = `${role === "host" ? "HOST" : "GUEST"} · ${label}`;
      if (matchText.textContent !== text) matchText.textContent = text;
      if (input.pressed?.("interact")) defense.updateAmmoPickup?.();
      if (phase === "victory" || phase === "defeat") {
        input.setGameplay?.(false);
        input.exitLock?.();
        return false;
      }
      return true;
    }
    return session;
  }
