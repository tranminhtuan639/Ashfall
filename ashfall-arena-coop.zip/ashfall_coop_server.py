"""Serve the Ashfall LAN demo and relay packets between two local browsers."""
import argparse
import json
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import secrets
from shutil import copyfileobj
from urllib.parse import urlsplit
from threading import Lock
import time

PAGE = Path(__file__).resolve().parent / "dist" / "index.html"
ROOMS = {}
LOCK = Lock()
TIMEOUT = 25


def exchange(route, body):
    now = time.monotonic()
    with LOCK:
        for code, room in list(ROOMS.items()):
            if any(now - player["last"] > TIMEOUT for player in room.values()):
                del ROOMS[code]

        if route == "/lan/host":
            if len(ROOMS) >= 32:
                return 503, {"error": "Đang có quá nhiều phòng."}
            while True:
                code = str(secrets.randbelow(900000) + 100000)
                if code not in ROOMS:
                    break
            token = secrets.token_urlsafe(24)
            ROOMS[code] = {token: {"last": now, "inbox": []}}
            return 200, {"code": code, "token": token}

        code = body.get("code")
        room = ROOMS.get(code) if isinstance(code, str) else None
        if not room:
            return 404, {"error": "Phòng đã đóng hoặc mã không đúng."}
        if route == "/lan/join":
            if len(room) != 1:
                return 409, {"error": "Phòng đã đủ hai người."}
            token = secrets.token_urlsafe(24)
            room[token] = {"last": now, "inbox": []}
            return 200, {"code": code, "token": token}

        token = body.get("token")
        player = room.get(token) if isinstance(token, str) else None
        if not player:
            return 403, {"error": "Phiên chơi không hợp lệ."}
        if route == "/lan/leave":
            del ROOMS[code]
            return 200, {}
        packets = body.get("packets", [])
        if not isinstance(packets, list) or len(packets) > 32 or any(
            not isinstance(packet, str) or len(packet) > 4000 for packet in packets
        ):
            return 400, {"error": "Gói tin không hợp lệ."}
        player["last"] = now
        connected = len(room) == 2
        if connected:
            other = next(value for key, value in room.items() if key != token)
            other["inbox"].extend(packets)
            del other["inbox"][:-96]
        inbox, player["inbox"] = player["inbox"], []
        return 200, {"connected": connected, "packets": inbox}


class Handler(BaseHTTPRequestHandler):
    def setup(self):
        super().setup()
        self.connection.settimeout(5)

    def respond(self, status, content, media_type):
        self.send_response(status)
        self.send_header("Content-Type", media_type)
        self.send_header("Content-Length", str(len(content)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        try:
            self.wfile.write(content)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def do_GET(self):
        if urlsplit(self.path).path not in ("/", "/index.html"):
            self.send_error(404)
            return
        try:
            with PAGE.open("rb") as page:
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Content-Length", str(PAGE.stat().st_size))
                self.send_header("Cache-Control", "no-cache")
                self.end_headers()
                copyfileobj(page, self.wfile)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def do_POST(self):
        if self.path not in ("/lan/host", "/lan/join", "/lan/poll", "/lan/leave"):
            self.send_error(404)
            return
        try:
            length = int(self.headers.get("Content-Length", "0"))
            if not 0 < length <= 140000:
                raise ValueError()
            body = json.loads(self.rfile.read(length))
            if not isinstance(body, dict):
                raise ValueError()
        except (ValueError, OSError):
            self.send_error(400)
            return
        status, data = exchange(self.path, body)
        self.respond(status, json.dumps(data).encode(), "application/json")

    def log_message(self, fmt, *args):
        if self.path != "/lan/poll":
            super().log_message(fmt, *args)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--bind", default="0.0.0.0")
    parser.add_argument("--port", type=int, default=8000)
    args = parser.parse_args()
    if not PAGE.is_file():
        parser.exit(1, f"Missing {PAGE.name}. Keep both files in the same folder.\n")
    with ThreadingHTTPServer((args.bind, args.port), Handler) as server:
        print(f"Ashfall LAN ready on {args.bind}:{args.port}. Open /?lan=1 for co-op.", flush=True)
        try:
            server.serve_forever()
        except KeyboardInterrupt:
            pass
